<?php
session_start();
$con=mysqli_connect('localhost','root','','ecommerce_website');
	$qq="SELECT cat_id FROM catogeries LIMIT 1";
	$runn=mysqli_query($con,$qq);
	$cat_id=0;
while($row=@mysqli_fetch_assoc($runn)){
	$cat_id=$row['cat_id'];
}
	

?>
<html>
<head><title></title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="style/style.css"/>
<script src="js/dropdown.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">



</head>
<body>
<!--top bar for social links START-->
<div class="top-bar" >


</div>
<!--top bar for social links END-->

<!--Header START-->
<div class="menu-bar">
<h1  style="margin-left:10%; color:white; display:inline; padding-top:40px; margin-top:0px;">LOGO HERE</h1>
<!--search form start-->
<form method="get" action="search.php" class="searchform">
<select  name="collection">
<option value="NULL"> All Collections </option>
<?php  
$q5="SELECT * FROM catogeries";
$run5=mysqli_query($con,$q5);
while($row1=mysqli_fetch_assoc($run5)){

?>
<option value="<?php echo $row1['cat_id'];  ?>"><?php  echo $row1['cat_name'];  ?> </option>
<?php  } ?>

</select>

<div>
<input type="text" name="search" style="border:none;" placeholder="Search Our Store"><button type="submit"><span class="glyphicon glyphicon-search" style="margin-top:2px;"></span></button>
</div>


</form>
<!--search form end-->
<ul class="menulist">
    <li style="padding-left:30px;"><span class="glyphicon glyphicon-map-marker"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Store Location</p></span></li>
	<a href="my-account.php"><li><i class="glyphicon glyphicon-user"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">My Account</p></i></li></a>
	<a href="cart.php"><li><i class="glyphicon glyphicon-shopping-cart"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Shopping Cart</p></i></li></a>
</ul>

</div>
<!--main menu start-->
<div class="main-menu">
	<ul>
		<li class="cat" ><i style="margin-right:10px;" class="glyphicon glyphicon-th-list"></i>ALL COLLECTIONS</li>
		<a href="index.php"><li class="smallcat">HOME</li></a>
		<a href="shop.php?catid=<?php echo $cat_id;  ?>"><li class="smallcat">SHOP</li></a>
		<a href="contact.php"><li class="smallcat">Contact Us</li></a>
		<li class="smallcat">BLOG</li>
	
	</ul>

</div>

<!--main menu end-->

<!--Header END-->
<!--dropdown category menu start-->
<div class="cat-drop-down"id="w">
	<ul>
	<?php
    $q4="SELECT cat_id,cat_name FROM catogeries";
	$run4=mysqli_query($con,$q4);
	while($row=mysqli_fetch_assoc($run4)){
	
	
	?>
		<a style="color:black; text-decoration:none; font-weight:bold;" href="shop.php?catid=<?php echo $row['cat_id'];  ?>"><li id="1" style="text-transform:capitalize;"><?php echo $row['cat_name']; ?></li></a>
	<?php
	}
	?>

	</ul>
</div>
<?php 
function mac()
{
/*
* Getting MAC Address using PHP
* Md. Nazmul Basher
*/

ob_start(); // Turn on output buffering
system('ipconfig /all'); //Execute external program to display output
$mycom=ob_get_contents(); // Capture the output into a variable
ob_clean(); // Clean (erase) the output buffer
$findme = "Physical";
$pmac = strpos($mycom, $findme); // Find the position of Physical text
$mac=substr($mycom,($pmac+36),17); // Get Physical Address
return $mac;
}

if(isset($_GET['pid']) and @$_GET['cart']==1){
	

$macad=mac();

$pid=$_GET['pid'];
$q2="SELECT * FROM cart WHERE p_id='$pid' AND mac_address='$macad'";
$run2=mysqli_query($con,$q2);
$x=0;
while($row=mysqli_fetch_assoc($run2)){
	$x=1;
}
if($x==0){
$q="INSERT INTO cart (p_id,mac_address,quantity) values('$pid','$macad',1)";
if(mysqli_query($con,$q)){
	echo "<div class='alert alert-success' style='text-align:center;'>Product Added to cart successfully</div>";
}
}
else{
		echo "<div class='alert alert-danger' style='text-align:center;'>You have already added that product to cart</div>";

}


}
?>
<!--dropdown category menu end-->
<!--Product Description  Main Start-->
<div class="container center product-desc">
<!--php code for order submission start-->
<?php

if(isset($_POST['submit']) and isset($_SESSION['email'])){
$size=$_POST['size'];
$color=$_POST['color'];
$pid=$_GET['pid'];
$email=$_SESSION['email'];
$date=date("Y-m-d");
$payment=$_POST['payment'];
$quantity=$_POST['quantity'];
$q1="INSERT INTO orders(payment_method,refund,delievery_status,order_date,email,p_id,success_status,size,color,quantity) values ('$payment',0,0,'$date','$email','$pid',1,'$size','$color','$quantity')";
if(mysqli_query($con,$q1)){
	echo "<div class='alert alert-success'>Order placed successfuly.Thanks for choosing Us</div>";
	$q="SELECT stock FROM products WHERE p_id='$pid'";
	$run=mysqli_query($con,$q);
	$row=mysqli_fetch_assoc($run);
	$stock=$row['stock']-$quantity;
	$qq="UPDATE products SET stock='$stock' WHERE p_id='$pid'";
	mysqli_query($con,$qq);
}
else{
	echo "something wrong";
}

}
else if(isset($_POST['submit']) and !isset($_SESSION['email'])){
	echo "<div class='alert alert-danger'>Please Signin first  to place order!</div>";
}
?>
<!--php code for order submission end-->
	<div class="row">
		<!--product images section start-->
		<?php
			if(isset($_GET['pid'])){
			$pid=$_GET['pid'];
			$q="SELECT * FROM products WHERE p_id='$pid'";
			$run=mysqli_query($con,$q);
			$row=mysqli_fetch_assoc($run);
			
		?>
		<div class="col-sm-5 row">
			<div class="col-sm-10" style="min-height:300px;  padding:0px;">
			<img id="screen" src="Products-images/<?php echo $row['img1']; ?>" style="width:100%; margin:0px;">
			</div> 
			<div class="col-sm-2 vertical-images">
			<?php if($row['img1']!=NULL){?>
			<img src="Products-images/<?php echo $row['img1']; ?>" style="width:100%; height:30">
			<?php } if($row['img2']!=NULL){ ?>
			<img src="Products-images/<?php echo $row['img2'];  ?>" style="width:100%; height:30">
			<?php } if($row['img3']!=NULL){ ?>
			<img src="Products-images/<?php echo $row['img3'];  ?>" style="width:100%; height:30">
			<?php  } if($row['img4']!=NULL){ ?>
			<img src="Products-images/<?php echo $row['img4'];  ?>" style="width:100%; height:30">
			<?php }if($row['img5']!=NULL){  ?>
			<img src="Products-images/<?php echo $row['img5'];  ?>" style="width:100%; height:30">
			<?php } ?>
			
			</div>
		</div>
		<!--Product Images Section END-->
		
		<!--Product Description Section Start-->
		<div class="col-sm-7 row">
			<div class="col-sm-2"></div>
			
			<div class="col-sm-10">
			<h1 style="text-transform:capitalize;"><?php echo $row['p_title']; ?></h2>
			<!--Rating Start-->
			
			<div style="float:right">
			<?php
			$pid=$_GET['pid'];
			$rateavg="SELECT ROUND(AVG(rate_value),0) FROM rating WHERE pid='$pid' GROUP BY pid";
			$raterun=mysqli_query($con,$rateavg);
			$raterow=mysqli_fetch_array($raterun);
			$rateleft=5-$raterow[0];
			while($raterow[0]!=0){
			$raterow[0]--;
			?>
			<span class="fa fa-star checked"></span>
			<?php } 
			while($rateleft!=0){
				$rateleft--;
				?>
			<span class="fa fa-star"></span>
			<?php } ?>
			</div>
			<!--Rating END-->
			<h4 style="color:orange; font-weight:bold;"><?php echo "Price:"."$".$row['discounted_price'];  ?></h4>
			<h5 style="text-decoration:line-through"><?php echo "Price:"."$".$row['regular_price'];  ?></h5>
			<p style="margin-top:10px;"><?php echo $row['description']; ?></p>
			<form method="post" action="product.php?pid=<?php echo $_GET['pid'];  ?>" style="margin-top:50px">
				<div class="form-group">
				<label  for="size">Select Size</label>
				<select class="form-control"  name="size">
				<option value="No Size">Select Size</option>
				<?php if($row['large_size']){  ?>
				<option value="largeSize">Large Size</option>
				<?php } if($row['med_size']){ ?>
				<option value="mediumSize">Medium Size</option>
				<?php } if($row['small_size']){ ?>
				<option value="smallSize">Small Size</option>
				<?php }if($row['x_large_size']){   ?>
				<option value="xLargeSize">Extra Large Size</option>
				<?php }?>
				
				</select>
			
				</div>
				<div class="form-group">
				<label  for="payment">Select Payment Method</label>
				<select class="form-control"  name="payment" required>
				<option value="paypal">Paypal</option>
				<option value="payoneer">Payoneer</option>
				<option value="stripe">Stripe</option>
				<option value="2checkout">2 Checkout</option>
				
				</select>
			
				</div>
				<div class="form-group">
				<label  for="color">Select Color</label>
				<select class="form-control"  name="color">
				<option value="No Color">Select Color</option>
				<?php  
				$pp=$_GET['pid'];
				$q2="SELECT * FROM colors WHERE pid='$pp'";
				$run2=mysqli_query($con,$q2);
				if($run2){
					echo "something wrong";
				}
				while($row1=mysqli_fetch_assoc($run2)){
				echo $row1['color_id'];
				?>
				<option value="<?php echo $row1['color_name'];?>" style="text-transform:capitalize; "><?php echo $row1['color_name'];  ?></option>
				<?php
				}
				?>
				
				</select>
				</div>
				<div class="form-group">
				<label  for="quantity">Quantity</label>
				<select class="form-control"  name="quantity">
				<?php  
				$ppp=$_GET['pid'];
				$q3="SELECT stock FROM products WHERE p_id='$ppp'";
				$run3=mysqli_query($con,$q3);
				$row4=mysqli_fetch_assoc($run3);
				$x=0;
				
				while($row4['stock']!=$x){
					$x++;
				?>
				<option value="<?php echo $x?>" style="text-transform:capitalize; "><?php echo $x;  ?></option>
				<?php
			
				}
				?>
				
				</select>
				<?php
				echo "<div class='badge' style='margin-top:5px;'>Products In Stock: ".$row4['stock']."</div>";
				?>
				</div>
				<div class="form-group">
				<?php if($row4['stock']!=0){?>
			    <input type="submit"  class="form-control btn btn-danger" name="submit" value="Proceed To Order">
				<?php }else{?>
				<div class="btn btn-danger btn-block disabled">Proceed To Order</div>
				<?php } ?>
				</div>
			
			
			</form>
			<a class="btn btn-success btn-block" href="product.php?cart=1&pid=<?php echo $_GET['pid']; ?>">Add To Cart</a>
			
			</div>
		
		
		</div>
		<?php
			}
		?>
		
		<!--Product description section END-->
	</div>
</div>
<!--Product Description Main End-->

<!--footer starts-->
<div class="footer row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="padding-top:30px;">
		<div class="col-sm-6">
			<h4>ABOUT US</h4>
		    <p ><span class="glyphicon glyphicon-map-marker" style="color:#ffa500;"></span> 474 Ontario St Toronto, ON M4X 1M7 Canada</p>
		    <p><span class="glyphicon glyphicon-earphone" style="color:#ffa500;"></span> (+92)-3118673628</p>
		    <p><span class="glyphicon glyphicon-envelope" style="color:#ffa500;"></span> naveedullah.baber@gmail.com</p>
		    <ul class="social">
				<li><i class="fab fa-facebook-square"></i></li>
				<li><i class="fab fa-google-plus"></i></li>
				<li><i class="fab fa-instagram"></i></li>
				<li><i class="fab fa-linkedin"></i></li>
				<li><i class="fab fa-pinterest"></i></li>
			</ul>
		</div>
		<div class="col-sm-6">
			<h4 style="margin-left:60px;">INFORMATION</h4>
		    <ul class="info">
				<li>
					<ul>
					<li>About Us</li>
					<li>Contact Us</li>
					
					</ul>
				
				</li>
				<li>
				    <ul>
					<li>Privacy Policy</li>
					<li>Refund Policy</li>
					
					</ul>
				
				</li>
				<li>
					<ul>
					<li>Return Policy</li>
					<li>Top Brands</li>
					
					</ul>
				
				
				</li>
			</ul>
		
		
		</div>
	
	</div>
	
	<div class="col-sm-2"></div>



</div>
<!--footer ends-->
<!--footer bottom section start-->
<div class="row" style="min-height:89px; color:white; background-color:#2c2c2c; border-top:0.02px solid grey;">
	<div class="col-sm-2" >
	</div>
	<div class="col-sm-8" style="margin-top:20px;">
		<div class="col-sm-6">
		&copy 2018 All Right Reserved
		</div>
		<div class="col-sm-6">
			<ul class="payment">
				<li><i class="fab fa-cc-paypal"></i></li>
				<li><i class="fab fa-cc-mastercard"></i></li>
				<li><i class="fab fa-cc-jcb"></i></li>
				<li><i class="fab fa-cc-discover"></i></li>
				<li><i class="fab fa-cc-visa"></i></li>
				<li><i class="fab fa-cc-amazon-pay"></i></li>
				<li><i class="fab fa-cc-apple-pay"></i></li>
				<li><i class="fab fa-cc-stripe"></i></li>
				
		 
		 
			</ul>
		
		 
		</div>
	
	</div>
	<div class="col-sm-2"></div>
	
</div>
<!--footer bottom section end-->


</body>
</html>