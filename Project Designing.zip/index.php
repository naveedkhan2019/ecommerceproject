<?php
$con=mysqli_connect('localhost','root','','ecommerce_website');
	$qq="SELECT cat_id FROM catogeries LIMIT 1";
	$runn=mysqli_query($con,$qq);
	$cat_id=0;
while($row=@mysqli_fetch_assoc($runn)){
	$cat_id=$row['cat_id'];
}
	

?>
<html>
<head><title></title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="style/style.css"/>
<script src="js/dropdown.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">



</head>
<body>
<!--top bar for social links START-->
<div class="top-bar" >


</div>
<!--top bar for social links END-->

<!--Header START-->
<div class="menu-bar">
<h1  style="margin-left:10%; color:white; display:inline; padding-top:40px; margin-top:0px;">LOGO HERE</h1>
<!--search form start-->
<form method="get" action="search.php" class="searchform">
<select  name="collection">
<option value="NULL"> All Collections </option>
<?php  
$q5="SELECT * FROM catogeries";
$run5=mysqli_query($con,$q5);
while($row1=mysqli_fetch_assoc($run5)){

?>
<option value="<?php echo $row1['cat_id'];  ?>"><?php  echo $row1['cat_name'];  ?> </option>
<?php  } ?>

</select>

<div>
<input type="text" name="search" style="border:none;" placeholder="Search Our Store"><button type="submit"><span class="glyphicon glyphicon-search" style="margin-top:2px;"></span></button>
</div>


</form>
<!--search form end-->
<ul class="menulist">
    <li style="padding-left:30px;"><span class="glyphicon glyphicon-map-marker"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Store Location</p></span></li>
	<a href="my-account.php"><li><i class="glyphicon glyphicon-user"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">My Account</p></i></li></a>
	<a href="cart.php"><li><i class="glyphicon glyphicon-shopping-cart"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Shopping Cart</p></i></li></a>
</ul>

</div>
<!--main menu start-->
<div class="main-menu">
	<ul>
		<li class="cat" ><i style="margin-right:10px;" class="glyphicon glyphicon-th-list"></i>ALL COLLECTIONS</li>
		<li class="smallcat">HOME</li>
		<a href="shop.php?catid=<?php echo $cat_id;  ?>"><li class="smallcat">SHOP</li></a>
		<a href="contact.php"><li class="smallcat">Contact Us</li></a>
		<li class="smallcat">BLOG</li>
	
	</ul>

</div>

<!--main menu end-->

<!--Header END-->
<!--dropdown category menu start-->
<div class="cat-drop-down"id="w">
	<ul>
	<?php
    $q4="SELECT cat_id,cat_name FROM catogeries";
	$run4=mysqli_query($con,$q4);
	while($row=mysqli_fetch_assoc($run4)){
	
	
	?>
		<a style="color:black; text-decoration:none; font-weight:bold;" href="shop.php?catid=<?php echo $row['cat_id'];  ?>"><li id="1" style="text-transform:capitalize;"><?php echo $row['cat_name']; ?></li></a>
	<?php
	}
	?>

	</ul>
</div>
<?php 
function mac()
{
/*
* Getting MAC Address using PHP
* Md. Nazmul Basher
*/

ob_start(); // Turn on output buffering
system('ipconfig /all'); //Execute external program to display output
$mycom=ob_get_contents(); // Capture the output into a variable
ob_clean(); // Clean (erase) the output buffer
$findme = "Physical";
$pmac = strpos($mycom, $findme); // Find the position of Physical text
$mac=substr($mycom,($pmac+36),17); // Get Physical Address
return $mac;
}

if(isset($_GET['pid']) and @$_GET['cart']==1){
	

$macad=mac();

$pid=$_GET['pid'];
$q2="SELECT * FROM cart WHERE p_id='$pid' AND mac_address='$macad'";
$run2=mysqli_query($con,$q2);
$x=0;
while($row=mysqli_fetch_assoc($run2)){
	$x=1;
}
if($x==0){
$q="INSERT INTO cart (p_id,mac_address,quantity) values('$pid','$macad',1)";
if(mysqli_query($con,$q)){
	echo "<div class='alert alert-success' style='text-align:center;'>Product Added to cart successfully</div>";
}
}
else{
		echo "<div class='alert alert-danger' style='text-align:center;'>You have already added that product to cart</div>";

}


}
?>
<!--dropdown category menu end-->


<?php
//Saving visitor data in database START
$macad=mac();
$date=date("Y-m-d");
$ip=$_SERVER['REMOTE_ADDR'];
$visitor="INSERT INTO visitors (ip_add,country,visit_date) VALUES ('$macad','Pakistan','$date')";
if(mysqli_query($con,$visitor)){
	//echo "done";
}
//Saving visitor data in database END
//finding country start--
/*
function getLocationInfoByIp(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = @$_SERVER['REMOTE_ADDR'];
    $result  = array('country'=>'', 'city'=>'');
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }else{
        $ip = $remote;
    }
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));    
    if($ip_data && $ip_data->geoplugin_countryName != null){
        $result['country'] = $ip_data->geoplugin_countryCode;
        $result['city'] = $ip_data->geoplugin_city;
    }
    return $result;
}

//finding country end
$c=getLocationInfoByIp();
echo $c['country'];
*/


?>


<div class="row">
<div class="col-sm-2">
</div>
<!--slider starts-->

<div class="slider col-sm-6" id="#slider">
<img id="slider1" src="images/img1.jpg">
<img id="slider2" src="images/img2.jpg">
<img id="slider3" src="images/img3.jpg">
<img id="slider4" src="images/img4.jpg">



</div>
<!--slider ends-->
<!--slider right start-->
<div class="col-sm-4">
	<div class="sliderrh row">
			<p class="col-lg-8">TOP BRAND</p>
			<ul class="col-lg-4">
			<!--	<li><i class="glyphicon glyphicon-menu-left"></i></li>
				<li><i class="glyphicon glyphicon-menu-right"></i></li>-->
			</ul>
	</div>
	<div class="sliderrslider">
		
			    <ul>
					<li class="row" style="margin-top:-10px;">
						<div class="col-sm-6 "><img  style="height:100px; width:100%;" src="images/dell.jpg" ></div>
						<div class="col-sm-6" style="text-align:center;"><h2 style="font-weight:bold; margin-top:30px;">DELL</h2>
							
						</div>
					
					</li>
					<li class="row">
					<div class="col-sm-6 "><img  style="height:100px; width:100%;" src="images/hp.png" ></div>
						<div class="col-sm-6" style="text-align:center;"><h3 style="font-weight:bold; margin-top:30px;">SAMSUNG</h3>
							
						</div>
					</li>
					<li class="row">
					<div class="col-sm-6 "><img  style="height:100px; width:100%;" src="images/samsung.jpeg" ></div>
						<div style="text-align:center;"><h2 style="font-weight:bold; margin-top:30px; ">HP</h2>
							
						</div>
					
					</li>
				
				</ul>
			
	</div>
</div>
<!--slider right end-->
</div>
<!--slider row end-->
<!--Featured collection start-->

<div class="featured-co"><h3 style="position:absolute; margin-top:-33px; font-weight:bold; font-size:26px; padding-bottom:3px; border-bottom:3px solid #ffa500;">Featured Collections</h3></div>
<div class="row">
   
	<div class="col-sm-2"></div>
	<div style="max-width:1130px; margin-top:20px;" class="col-sm-9 row">
		<a style="color:black;" href="shop.php?catid=3"><div class="col-sm-4 f-item" style="min-height:400px; cursor:pointer;">
			<img src="images/img6.jpg" style="width:300px; height:300px;" />
			<div class="f-item-1"><h4 style="font-weight:bold;">LAPTOPS</h4></div>
		</div></a>
		<a style="color:black;"  href="shop.php?catid=6"><div class="col-sm-4 f-item" style="min-height:400px; cursor:pointer;">
			<img src="images/img7.jpg" style="width:300px; height:300px;">
			<div class="f-item-1"><h4 style="font-weight:bold;">MAKE UP</h4></div>
		</div></a>
		<a style="color:black;"  href="shop.php?catid=7"><div class="col-sm-4 f-item" style="min-height:400px; cursor:pointer;">
			<img style="width:300px; height:300px;" src="images/mobile.png">
			<div class="f-item-1"><h4 style="font-weight:bold;">MOBILES</h4></div>
		</div></a>
		
	
	</div>
	<div class="col-sm-1"></div>
	

</div>
<!--Featured collection end-->
<!--after featured product seasion start-->
<div class="row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="width:1130px;">
		<div class="row" style="margin-top:10px;">
		    <div ><h3 style="position:absolute;  margin-top:-33px; font-weight:bold; font-size:20px; padding-bottom:8px; border-bottom:3px solid #ffa500;">LATEST PRODUCTS</h3></div>
			<div class="col-sm-3" style="border-top:2px solid #e5e5e5;padding:0px;">
				<div class="latest-products">
					<ul>
					<!--php code for selecting latest products START-->
					<?php
					$q1="SELECT * FROM products ORDER BY p_id DESC LIMIT 0,3";
					$run1=mysqli_query($con,$q1);
					if(!$run1){
						echo "something going wrong";
					}
					
					while($row=@mysqli_fetch_assoc($run1)){
					
					
					?>
					
					<!--php code for selecting latest product END-->
						<li class="row">
						
							<div class="col-sm-5 picrotate" style="min-height:120px; cursor:pointer; ">
							<img src="products-images/<?php echo $row['img1'];  ?>" id="picrotate" style="width:100%; max-height:120px;">
							</div>
							<div class="col-sm-7">
								<a href="product.php?pid=<?php echo $row['p_id']; ?>" style="font-size:16px; font-weight:bold;"><?php echo $row['p_title']; ?></a>
								<p style="font-weight:bold; color:#ffa500;">$<?php echo "Price:"."$".$row['discounted_price'];  ?></p>
								<p style="text-decoration:line-through;">$<?php echo "Price:"."$".$row['regular_price'];?></p>
							</div>
						</li>
						
					<?php
					
					}
					?>
					</ul>
				</div>
			
			</div>
			<div class="col-sm-6" style="border-top:2px solid #e5e5e5;padding:0px;">
			<div  ><h3 style="position:absolute;  margin-top:-33px; margin-left:15px;font-weight:bold; font-size:20px; padding-bottom:8px; border-bottom:3px solid #ffa500;">RANDOM SELECTION</h3></div>
			<div class="latest-products" style="width:95%; min-height:420px; margin:auto; margin-top:20px;">
					<ul>
						<li class="row"  style="">
						<?php
						$q8="SELECT * FROM products ORDER BY RAND() LIMIT 1";
						$run8=mysqli_query($con,$q8);
						$row8=mysqli_fetch_assoc($run8);
						
						?>
							<div class="col-sm-6 picrotate" style="margin-top:20%; cursor:pointer; ">
							<img  src="Products-images/<?php echo $row8['img1']; ?>" id="picrotate" style=" margin-left:20%; max-height:120px;">
							</div>
							<div class="col-sm-6">
								<a href="product.php?pid=<?php echo $row8['p_id'];?>"><h5 style="font-size:16px; font-weight:bold; text-transform:capitalize;"><?php echo $row8['p_title']; ?></h5></a>
								<!--Rating Start-->
			
								<p>
								<?php
								$pid=$row8['p_id'];
								$rateavg="SELECT ROUND(AVG(rate_value),0) FROM rating WHERE pid='$pid' GROUP BY pid";
								$raterun=mysqli_query($con,$rateavg);
								$raterow=mysqli_fetch_array($raterun);
								$rateleft=5-$raterow[0];
								while($raterow[0]!=0){
								$raterow[0]--;
								?>
			
							<span class="fa fa-star checked"></span>
							<?php } 
								while($rateleft!=0){
								$rateleft--;
								?>
								<span class="fa fa-star"></span>
								<?php } ?>
							</p>
								<!--Rating END-->
								<p style="font-weight:bold; color:#ffa500;"><?php echo "Price:"."$".$row8['discounted_price']; ?></p>
								<p style="text-decoration:line-through;"><?php echo "Price:"."$".$row8['regular_price']; ?></p>
								<p><?php echo substr($row8['description'],0,500);  ?></p>
								<ul class="options">
									<li ><a href="index.php?cart=1&pid=<?php echo $row8['p_id']; ?>"><button class="btn btn-default">Add to Cart</button></a></li>
								
								</ul>
								
							</div>
						</li>
						
					</ul>
				</div>
			
			
			</div>
			<div class="col-sm-3" style="border-top:2px solid #e5e5e5;padding:0px;">
			<div ><h3 style="position:absolute;  margin-top:-33px; font-weight:bold; font-size:20px; padding-bottom:8px; border-bottom:3px solid #ffa500;">LATEST PRODUCTS</h3></div>
			<div class="latest-products">
					<ul>
						<!--php code for selecting latest products START-->
					<?php
					$q1="SELECT * FROM products ORDER BY p_id DESC LIMIT 3,3";
					$run1=mysqli_query($con,$q1);
					if(!$run1){
						echo "something going wrong";
					}
					
					while($row=@mysqli_fetch_assoc($run1)){
					
					
					?>
					
					<!--php code for selecting latest product END-->
						<li class="row">
						
							<div class="col-sm-5 picrotate" style="min-height:120px; cursor:pointer; ">
							<img src="products-images/<?php echo $row['img1'];  ?>" id="picrotate" style="width:100%; max-height:120px;">
							</div>
							<div class="col-sm-7">
								<a href="product.php?pid=<?php echo $row['p_id']; ?>" style="font-size:16px; font-weight:bold;"><?php echo $row['p_title']; ?></a>
								<p style="font-weight:bold; color:#ffa500;">$<?php echo "Price:"."$".$row['discounted_price'];  ?></p>
								<p style="text-decoration:line-through;">$<?php echo "Price:"."$".$row['regular_price'];?></p>
							</div>
						</li>
						
					<?php
					
					}
					?>
						
						
					</ul>
				</div>
			
			
			</div>
	
		
		</div>
	<!--before footer section start-->
	<div class="best-seller">
		<ul>
			<li id="seller"><h3>BEST SELLER</h3></li>
			<li id="feature" style="margin-left:20px; color:gray; border:none;"><h3>FEATURED PRODUCTS</h3></li>
		</ul>
		<!--best selling start-->
		<div id="sell" class="row" style="">
				<!--php code for featured products start-->
		<?php
		$q22="SELECT COUNT(p_id) AS COUNT,p_id FROM orders GROUP BY p_id ORDER BY COUNT DESC";
		$run2=mysqli_query($con,$q22);
		$count=0;
		while($row1=@mysqli_fetch_assoc($run2)){
			$pid=$row1['p_id'];
			$q="SELECT * FROM products WHERE p_id='$pid'";
			$run=mysqli_query($con,$q);
			$row=mysqli_fetch_assoc($run);
			$count++;
		
		?>
		<!--php code for featured products end-->
			<div class="col-sm-3 product-show">
				<div class="picrotate">
				    <img id="picrotate" src="products-images/<?php echo $row['img1']; ?>">
					<a href="product.php?pid=<?php echo $row['p_id']; ?>"><?php echo $row['p_title']; ?></a>
			<!--Rating Start-->
			
			<p>
			<?php
			$pid=$row['p_id'];
			$rateavg="SELECT ROUND(AVG(rate_value),0) FROM rating WHERE pid='$pid' GROUP BY pid";
			$raterun=mysqli_query($con,$rateavg);
			$raterow=mysqli_fetch_array($raterun);
			$rateleft=5-$raterow[0];
			while($raterow[0]!=0){
			$raterow[0]--;
			?>
			
			<span class="fa fa-star checked"></span>
			<?php } 
			while($rateleft!=0){
				$rateleft--;
				?>
			<span class="fa fa-star"></span>
			<?php } ?>
			</p>
			<!--Rating END-->
					<p style="font-weight:bold; color:orange;"><?php echo "Price:"."$".$row['discounted_price']; ?></p>
					<p style="text-decoration:line-through;"><?php echo "Price:"."$".$row['regular_price']; ?></p>
					<br><a href="index.php?cart=1&pid=<?php echo $row['p_id']; ?>"><button  class="btn btn-default" style="">Add to Cart</button></a>
				</div>
				
			</div>
			<?php
			if($count==8){
				break;
			}
			
		}
			?>
			
		
		</div>
		<!--best selling end-->
		<!--feature product start-->
		<div id="feat">
		
		<!--php code for featured products start-->
		<?php
		$q2="SELECT * FROM products ORDER BY RAND() LIMIT 0,8";
		$run=mysqli_query($con,$q2);
		while($row=@mysqli_fetch_assoc($run)){
			
		
		?>
		<!--php code for featured products end-->
			<div class="col-sm-3 product-show">
				<div class="picrotate">
				    <img id="picrotate" src="products-images/<?php echo $row['img1']; ?>">
					<a href="product.php?pid=<?php echo $row['p_id']; ?>"><?php echo $row['p_title']; ?></a>
			<!--Rating Start-->
			
			<p>
			<?php
			$pid=$row['p_id'];
			$rateavg="SELECT ROUND(AVG(rate_value),0) FROM rating WHERE pid='$pid' GROUP BY pid";
			$raterun=mysqli_query($con,$rateavg);
			$raterow=mysqli_fetch_array($raterun);
			$rateleft=5-$raterow[0];
			while($raterow[0]!=0){
			$raterow[0]--;
			?>
			
			<span class="fa fa-star checked"></span>
			<?php } 
			while($rateleft!=0){
				$rateleft--;
				?>
			<span class="fa fa-star"></span>
			<?php } ?>
			</p>
			<!--Rating END-->
					<p style="font-weight:bold; color:orange;"><?php echo "Price:"."$".$row['discounted_price']; ?></p>
					<p style="text-decoration:line-through;"><?php echo "Price:"."$".$row['regular_price']; ?></p>
					<br><a href="index.php?cart=1&pid=<?php echo $row['p_id']; ?>"><button  class="btn btn-default" style="">Add to Cart</button></a>
				</div>
				
			</div>
			<?php
			
		}
			?>
		
		
		
		</div>
		<!--feature product end-->
		
		
	
	
	</div>
	<!--before footer section end-->
	</div>

</div>
<!--after each product session end-->






<!--footer starts-->
<div class="footer row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="padding-top:30px;">
		<div class="col-sm-6">
			<h4>ABOUT US</h4>
		    <p ><span class="glyphicon glyphicon-map-marker" style="color:#ffa500;"></span> 474 Ontario St Toronto, ON M4X 1M7 Canada</p>
		    <p><span class="glyphicon glyphicon-earphone" style="color:#ffa500;"></span> (+92)-3118673628</p>
		    <p><span class="glyphicon glyphicon-envelope" style="color:#ffa500;"></span> naveedullah.baber@gmail.com</p>
		    <ul class="social">
				<li><i class="fab fa-facebook-square"></i></li>
				<li><i class="fab fa-google-plus"></i></li>
				<li><i class="fab fa-instagram"></i></li>
				<li><i class="fab fa-linkedin"></i></li>
				<li><i class="fab fa-pinterest"></i></li>
			</ul>
		</div>
		<div class="col-sm-6">
			<h4 style="margin-left:60px;">INFORMATION</h4>
		    <ul class="info">
				<li>
					<ul>
					<li>About Us</li>
					<li>Contact Us</li>
					
					</ul>
				
				</li>
				<li>
				    <ul>
					<li>Privacy Policy</li>
					<li>Refund Policy</li>
					
					</ul>
				
				</li>
				<li>
					<ul>
					<li>Return Policy</li>
					<li>Top Brands</li>
					
					</ul>
				
				
				</li>
			</ul>
		
		
		</div>
	
	</div>
	
	<div class="col-sm-2"></div>



</div>
<!--footer ends-->
<!--footer bottom section start-->
<div class="row" style="min-height:89px; color:white; background-color:#2c2c2c; border-top:0.02px solid grey;">
	<div class="col-sm-2" >
	</div>
	<div class="col-sm-8" style="margin-top:20px;">
		<div class="col-sm-6">
		&copy 2018 All Right Reserved
		</div>
		<div class="col-sm-6">
			<ul class="payment">
				<li><i class="fab fa-cc-paypal"></i></li>
				<li><i class="fab fa-cc-mastercard"></i></li>
				<li><i class="fab fa-cc-jcb"></i></li>
				<li><i class="fab fa-cc-discover"></i></li>
				<li><i class="fab fa-cc-visa"></i></li>
				<li><i class="fab fa-cc-amazon-pay"></i></li>
				<li><i class="fab fa-cc-apple-pay"></i></li>
				<li><i class="fab fa-cc-stripe"></i></li>
				
		 
		 
			</ul>
		
		 
		</div>
	
	</div>
	<div class="col-sm-2"></div>
	
</div>
<!--footer bottom section end-->


</body>
</html>