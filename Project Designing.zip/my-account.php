



<?php
session_start();
$con=mysqli_connect("localhost","root","","ecommerce_website");
if(isset($_SESSION['email'])){
	echo "<script>location.href='user.php'</script>";
	exit;
}

	$qq="SELECT cat_id FROM catogeries LIMIT 1";
	$runn=mysqli_query($con,$qq);
	$cat_id=0;
while($row=@mysqli_fetch_assoc($runn)){
	$cat_id=$row['cat_id'];
}
	

?>
<html>
<head><title></title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="style/style.css"/>
<script src="js/dropdown.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">



</head>
<body>
<!--top bar for social links START-->
<div class="top-bar" >


</div>
<!--top bar for social links END-->

<!--Header START-->
<div class="menu-bar">
<h1  style="margin-left:10%; color:white; display:inline; padding-top:40px; margin-top:0px;">LOGO HERE</h1>
<!--search form start-->
<form method="get" action="search.php" class="searchform">
<select  name="collection">
<option value="NULL"> All Collections </option>
<?php  
$q5="SELECT * FROM catogeries";
$run5=mysqli_query($con,$q5);
while($row1=mysqli_fetch_assoc($run5)){

?>
<option value="<?php echo $row1['cat_id'];  ?>"><?php  echo $row1['cat_name'];  ?> </option>
<?php  } ?>

</select>

<div>
<input type="text" name="search" style="border:none;" placeholder="Search Our Store"><button type="submit"><span class="glyphicon glyphicon-search" style="margin-top:2px;"></span></button>
</div>


</form>
<!--search form end-->
<ul class="menulist">
    <li style="padding-left:30px;"><span class="glyphicon glyphicon-map-marker"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Store Location</p></span></li>
	<a href="my-account.php"><li><i class="glyphicon glyphicon-user"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">My Account</p></i></li></a>
	<a href="cart.php"><li><i class="glyphicon glyphicon-shopping-cart"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Shopping Cart</p></i></li></a>
</ul>

</div>
<!--main menu start-->
<div class="main-menu">
	<ul>
		<li class="cat" ><i style="margin-right:10px;" class="glyphicon glyphicon-th-list"></i>ALL COLLECTIONS</li>
		<a href="index.php"><li class="smallcat">HOME</li></a>
		<a href="shop.php?catid=<?php echo $cat_id;  ?>"><li class="smallcat">SHOP</li></a>
		<a href="contact.php"><li class="smallcat">Contact Us</li></a>
		<li class="smallcat">BLOG</li>
	
	</ul>

</div>

<!--main menu end-->

<!--Header END-->
<!--dropdown category menu start-->

<!--my-account part start-->
<div class="best-seller container" style="margin-top:100px; min-height:400px;">
		<ul>
			<li id="seller"><h3>LOGIN</h3></li>
			<li id="feature" style="margin-left:20px; color:gray; border:none;"><h3>SIGN UP</h3></li>
		</ul>
		<!--LOGIN START-->
		<div class="container login" id="sell">
		<form method="post" action="">
		<div class="form-group ">
		<label class="control-label" for="email">Enter Email Address:</label>
		<input type="text" name="email" placeholder="Enter email" class="form-control" required>
		</div>
		
		<div class="form-group ">
		<label class="control-label" for="password">Password:</label>
		<input type="password" name="password" placeholder="Enter password" class="form-control" required>
		</div>
		<input type="submit" name="login" href="" class="btn btn-default" value="Sign In">
	
		</form>
		
		</div>
		<!--LOGIN END-->
		<!--php code for login start-->
		<?php
		if(isset($_POST['login'])){
			$email=$_POST['email'];
			$password=$_POST['password'];
			$que="SELECT email,password from customer";
			$run=mysqli_query($con,$que);
			while($row=@mysqli_fetch_assoc($run)){
				if($row['email']=$email and  $row['password']=$password){
				$_SESSION['email']=$email;
				echo "<script>location.href='user.php';</script>";
				exit;
				}
				else{
					echo "something went rong.Try Again";
				}
			}
			
			
			
			
		}
		?>
		<!--php code for login end-->
		<!--SIGNUP START-->
		<div class="container login" id="feat">
		<form action="" method="post">
		<div class="form-group">
		<label class="control-label" for="fname">Enter Full Name</label>
		<input type="text" name="fname" placeholder="Full Name" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="email">Enter Email Address</label>
		<input type="text" name="email" placeholder="Enter email" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="country">Country</label>
		<input type="text" name="country" placeholder="Enter country" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="city">City</label>
		<input type="text" name="city" placeholder="Enter city" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="province">State/Province</label>
		<input type="text" name="province" placeholder="Enter state/province" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="postcode">Postal Code</label>
		<input type="text" name="postcode" placeholder="Enter postal code" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="streetadd">Street Address</label>
		<input type="text" name="streetadd" placeholder="Your street address" class="form-control" required>
		</div>
		<div class="form-group ">
		<label class="control-label" for="password">Password:</label>
		<input type="password" name="password" placeholder="Enter password" class="form-control" required>
		</div>
		<input type="submit" name="submit" class="btn btn-default" value="Sign Up">
	
		</form>
		
		</div>
		<!--php code for signup-->
		<?php
		if(isset($_POST['submit'])){
			$fname=$_POST['fname'];
			$email=$_POST['email'];
			$password=$_POST['password'];
			$country=$_POST['country'];
			$city=$_POST['city'];
			$postcode=$_POST['postcode'];
			$province=$_POST['province'];
			$streetadd=$_POST['streetadd'];
			$query="INSERT INTO customer values('$email','$fname','$password','$country','$city','$postcode','$province','$streetadd')";
			if(mysqli_query($con,$query)){
				$_SESSION['email']=$email;
				echo "<script>location.href='user.php';</script>";
			}
			else{
				echo "something going wrong";
			}
			
		}
		
		
		?>
		<!--php code for signup-->
		<!--SIGNUP END-->
</div>

















<!--my-account part end-->




<!--footer starts-->
<div class="footer row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="padding-top:30px;">
		<div class="col-sm-6">
			<h4>ABOUT US</h4>
		    <p ><span class="glyphicon glyphicon-map-marker" style="color:#ffa500;"></span> 474 Ontario St Toronto, ON M4X 1M7 Canada</p>
		    <p><span class="glyphicon glyphicon-earphone" style="color:#ffa500;"></span> (+92)-3118673628</p>
		    <p><span class="glyphicon glyphicon-envelope" style="color:#ffa500;"></span> naveedullah.baber@gmail.com</p>
		    <ul class="social">
				<li><i class="fab fa-facebook-square"></i></li>
				<li><i class="fab fa-google-plus"></i></li>
				<li><i class="fab fa-instagram"></i></li>
				<li><i class="fab fa-linkedin"></i></li>
				<li><i class="fab fa-pinterest"></i></li>
			</ul>
		</div>
		<div class="col-sm-6">
			<h4 style="margin-left:60px;">INFORMATION</h4>
		    <ul class="info">
				<li>
					<ul>
					<li>About Us</li>
					<li>Contact Us</li>
					
					</ul>
				
				</li>
				<li>
				    <ul>
					<li>Privacy Policy</li>
					<li>Refund Policy</li>
					
					</ul>
				
				</li>
				<li>
					<ul>
					<li>Return Policy</li>
					<li>Top Brands</li>
					
					</ul>
				
				
				</li>
			</ul>
		
		
		</div>
	
	</div>
	
	<div class="col-sm-2"></div>



</div>
<!--footer ends-->
<!--footer bottom section start-->
<div class="row" style="min-height:89px; color:white; background-color:#2c2c2c; border-top:0.02px solid grey;">
	<div class="col-sm-2" >
	</div>
	<div class="col-sm-8" style="margin-top:20px;">
		<div class="col-sm-6">
		&copy 2018 All Right Reserved
		</div>
		<div class="col-sm-6">
			<ul class="payment">
				<li><i class="fab fa-cc-paypal"></i></li>
				<li><i class="fab fa-cc-mastercard"></i></li>
				<li><i class="fab fa-cc-jcb"></i></li>
				<li><i class="fab fa-cc-discover"></i></li>
				<li><i class="fab fa-cc-visa"></i></li>
				<li><i class="fab fa-cc-amazon-pay"></i></li>
				<li><i class="fab fa-cc-apple-pay"></i></li>
				<li><i class="fab fa-cc-stripe"></i></li>
				
		 
		 
			</ul>
		
		 
		</div>
	
	</div>
	<div class="col-sm-2"></div>
	
</div>
<!--footer bottom section end-->


</body>
</html>