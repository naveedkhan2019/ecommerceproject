/*var x=1,expandend,collapseend;

function expand(){
	expandend=setInterval(styleediting,30);
}
function styleediting(){
document.getElementById(x).style="display:block;";
x++;
if(x==6){
	clearInterval(expandend);
	x--;
}
}

function collapse(){
		collapseend=setInterval(stylecollapsing,30);
}
function stylecollapsing(){
	document.getElementById(x).style="display:none;";
x--;
if(x==0){
	clearInterval(collapseend);
	x++;
}
}
*/
var slider1=1,sliderwidth=100,stop1,round=0;
//setInterval(slider,4000);
$(document).ready(function(){
$(".cat").click(function(){
$("#w").slideToggle();
}
);


}
);


function slider(){
	stop1=setInterval(collapse,100);
}
function collapse(){
	sliderwidth=sliderwidth-10;
	var zz=document.getElementById("slider"+slider1);
	zz.style="width:"+sliderwidth+"%;";
	
if(sliderwidth==0){
	clearInterval(stop1);
	round++;
if(round<4){
	zz.style="width=100%;display:none;";
}
else{
	round=0;
	document.getElementById("slider1").style="width=100%;display:block;";
	document.getElementById("slider2").style="width=100%;display:block;";
	document.getElementById("slider3").style="width=100%;display:block;";
	document.getElementById("slider4").style="width=100%;display:block;";
}
	sliderwidth=100;
	
	if(slider1!=4){
		slider1++;
		
	}
	else{
		slider1=1;
	}

	
}
	
}

//Full Jquery HERE
$(document).ready(function(){
$("#seller").click(function(){
	$("#seller h3").css({
		"color":"black",	
	}
	);
	$("#seller").css({
		"border-bottom":"2px solid orange",	
	}
	);
	$("#feature h3").css({
	"color":"gray",
	}
	);
	$("#feature").css({
	"border-bottom":"none",
	}
	);
	$("#feat").fadeOut("slow",function(){
		$("#sell").fadeIn();
	});
	
	
}
	
);

$("#feature").click(function(){
	$("#feature h3").css({
		"color":"black"
	}
	);
	$("#feature").css({
		"border-bottom":"2px solid orange"
	}
	);
	$("#seller h3").css({
		"color":"gray"
	}
	);
	$("#seller").css({
		"border-bottom":"none"
	}
	);
	$("#sell").fadeOut("slow",function(){
		$("#feat").fadeIn();
	}
	);
	
}
	
);

$("#dstatus").click(function(){
	
	$(this).css({
		"background-color":"orange",
		"border":"none"
	}
	);
	$("#dash").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#review").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#refundstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
	});
	
	$("#dashboard").fadeOut(0,function(){
		$("#del").fadeIn("slow");
	}
	);
	$("#refund").fadeOut(0,function(){
		$("#del").fadeIn("slow");
	}
	);
	$("#reviewsys").fadeOut(0,function(){
		$("#del").fadeIn("slow");
	}
	);
	
}
);

$("#dash").click(function(){
	$(this).css({
		"background-color":"orange",
		"border":"none"
	}
	);
	$("#dstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#review").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#refundstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
	});
	
	$("#del").fadeOut(0,function(){
		$("#dashboard").fadeIn("slow");
	}
	);
	$("#refund").fadeOut(0,function(){
		$("#dashboard").fadeIn("slow");
	}
	);
	$("#reviewsys").fadeOut(0,function(){
		$("#dashboard").fadeIn("slow");
	}
	);
	
	
}
);
$("#refundstatus").click(function(){
	$(this).css({
		"background-color":"orange",
		"border":"none"
	}
	);
	$("#dash").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#review").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#dstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
	});
	
	$("#del").fadeOut(0,function(){
		$("#refund").fadeIn("slow");
	}
	);
	
	$("#dashboard").fadeOut(0,function(){
		$("#refund").fadeIn("slow");
	}
	);
	$("#reviewsys").fadeOut(0,function(){
		$("#refund").fadeIn("slow");
	}
	);
	
	
}
);
$("#review").click(function(){
	$(this).css({
		"background-color":"orange",
		"border":"none"
	}
	);
	$("#dash").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#refundstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
		
		
	});
	$("#dstatus").css({
		"background-color":"white",
		"border":"1px solid grey"
	});
	
	$("#del").fadeOut(0,function(){
		$("#reviewsys").fadeIn("slow");
	}
	);
	
	$("#dashboard").fadeOut(0,function(){
		$("#reviewsys").fadeIn("slow");
	}
	);
	$("#refund").fadeOut(0,function(){
		$("#reviewsys").fadeIn("slow");
	}
	);
	
	
}
);


	
	
}
);

function imagechange(x){
	document.getElementById('screen').src="Products-images/dellimage2.jpg";
}