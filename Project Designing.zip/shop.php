<?php
$con=mysqli_connect('localhost','root','','ecommerce_website');
	$qq="SELECT cat_id FROM catogeries LIMIT 1";
	$runn=mysqli_query($con,$qq);
	$cat_id=0;
while($row=@mysqli_fetch_assoc($runn)){
	$cat_id=$row['cat_id'];
}
	

?>
<html>
<head><title></title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="style/style.css"/>
<script src="js/dropdown.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">



</head>
<body>
<!--top bar for social links START-->
<div class="top-bar" >


</div>
<!--top bar for social links END-->

<!--Header START-->
<div class="menu-bar">
<h1  style="margin-left:10%; color:white; display:inline; padding-top:40px; margin-top:0px;">LOGO HERE</h1>
<!--search form start-->
<form method="get" action="search.php" class="searchform">
<select  name="collection">
<option value="NULL"> All Collections </option>
<?php  
$q5="SELECT * FROM catogeries";
$run5=mysqli_query($con,$q5);
while($row1=mysqli_fetch_assoc($run5)){

?>
<option value="<?php echo $row1['cat_id'];  ?>"><?php  echo $row1['cat_name'];  ?> </option>
<?php  } ?>

</select>

<div>
<input type="text" name="search" style="border:none;" placeholder="Search Our Store"><button type="submit"><span class="glyphicon glyphicon-search" style="margin-top:2px;"></span></button>
</div>


</form>
<!--search form end-->
<ul class="menulist">
    <li style="padding-left:30px;"><span class="glyphicon glyphicon-map-marker"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Store Location</p></span></li>
	<a href="my-account.php"><li><i class="glyphicon glyphicon-user"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">My Account</p></i></li></a>
	<a href="cart.php"><li><i class="glyphicon glyphicon-shopping-cart"><br><p style="color:white; font-size:14px; line-height:20px; word-spacing:-10px;">Shopping Cart</p></i></li></a>
</ul>

</div>
<!--main menu start-->
<div class="main-menu">
	<ul>
		<li class="cat" ><i style="margin-right:10px;" class="glyphicon glyphicon-th-list"></i>ALL COLLECTIONS</li>
		<a href="index.php"><li class="smallcat">HOME</li></a>
		<li class="smallcat">SHOP</li>
		<a href="contact.php"><li class="smallcat">Contact Us</li></a>
		<li class="smallcat">BLOG</li>
	
	</ul>

</div>

<!--main menu end-->

<!--Header END-->
<!--dropdown category menu start-->
<div class="cat-drop-down"id="w">
	<ul>
	<?php
    $q4="SELECT cat_id,cat_name FROM catogeries";
	$run4=mysqli_query($con,$q4);
	while($row=mysqli_fetch_assoc($run4)){
	
	
	?>
		<a style="color:black; text-decoration:none; font-weight:bold;" href="shop.php?catid=<?php echo $row['cat_id'];  ?>"><li id="1" style="text-transform:capitalize;"><?php echo $row['cat_name']; ?></li></a>
	<?php
	}
	?>

	</ul>
</div>
<?php 
function mac()
{
/*
* Getting MAC Address using PHP
* Md. Nazmul Basher
*/

ob_start(); // Turn on output buffering
system('ipconfig /all'); //Execute external program to display output
$mycom=ob_get_contents(); // Capture the output into a variable
ob_clean(); // Clean (erase) the output buffer
$findme = "Physical";
$pmac = strpos($mycom, $findme); // Find the position of Physical text
$mac=substr($mycom,($pmac+36),17); // Get Physical Address
return $mac;
}

if(isset($_GET['pid']) and @$_GET['cart']==1){
	

$macad=mac();

$pid=$_GET['pid'];
$q2="SELECT * FROM cart WHERE p_id='$pid' AND mac_address='$macad'";
$run2=mysqli_query($con,$q2);
$x=0;
while($row=mysqli_fetch_assoc($run2)){
	$x=1;
}
if($x==0){
$q="INSERT INTO cart (p_id,mac_address,quantity) values('$pid','$macad',1)";
if(mysqli_query($con,$q)){
	echo "<div class='alert alert-success' style='text-align:center;'>Product Added to cart successfully</div>";
}
}
else{
		echo "<div class='alert alert-danger' style='text-align:center;'>You have already added that product to cart</div>";

}


}
?>
<!--dropdown category menu end-->
<div class="row">
<div class="col-sm-2">
</div>


<!--Main Product area start-->
<div class="row cat-menu container-fluid">
	<div class="col-sm-2">
	<?php 
	$q1="SELECT * FROM catogeries";
	$run=mysqli_query($con,$q1);
	while($row=mysqli_fetch_assoc($run)){
	?>
	<a href="shop.php?catid=<?php echo $row['cat_id'];  ?>" class="btn btn-default btn-block" style="text-transform:capitalize;"><?php echo $row['cat_name']; ?></a>
	<?php
	}
	?>
	</div>
	
	<div class="col-sm-9 best-seller" style="border:none;">
	<!--php code for products START-->
	<?php
	if(isset($_GET['catid'])){
		$cat=$_GET['catid'];
	$q2="SELECT * FROM brands WHERE cat_id='$cat'";
	$run1=mysqli_query($con,$q2);
	if(!$run1){
		echo "something wrong";
	}
	while($row1=mysqli_fetch_assoc($run1)){
		$brand=$row1['brand_name'];
		$brand_id=$row1['brand_id'];
	?>
	<!--php code for products END-->
		<ul >
			<li id="seller"><h3 style="text-transform:uppercase; "><?php echo $brand; ?></h3></li>
		</ul>
		<!--best selling start-->
		<div id="sell" class="row" style="margin-bottom:50px; border-top:2px solid #e5e5e5;">
		<?php
		$q3="SELECT * FROM products WHERE cat_id='$cat' AND brand_id='$brand_id'";
		$run2=mysqli_query($con,$q3);
		if(!$run2){
		echo "something wrong";
	}
		while($row2=mysqli_fetch_assoc($run2)){
		?>
		
			<div class="col-sm-3 product-show">
				<div class="picrotate">
				    <img id="picrotate" src="Products-images/<?php echo $row2['img1']; ?>">
					<a href="product.php?pid=<?php echo $row2['p_id']; ?>"><?php echo $row2['p_title'];  ?></a><br>
					<!--Rating Start-->
			
								<p>
								<?php
								$pid=$row2['p_id'];
								$rateavg="SELECT ROUND(AVG(rate_value),0) FROM rating WHERE pid='$pid' GROUP BY pid";
								$raterun=mysqli_query($con,$rateavg);
								$raterow=mysqli_fetch_array($raterun);
								$rateleft=5-$raterow[0];
								while($raterow[0]!=0){
								$raterow[0]--;
								?>
			
							<span class="fa fa-star checked"></span>
							<?php } 
								while($rateleft!=0){
								$rateleft--;
								?>
								<span class="fa fa-star"></span>
								<?php } ?>
							</p>
								<!--Rating END-->
					<p style="font-weight:bold; color:orange;"><?php echo "Price:"."$".$row2['discounted_price']; ?></p>
					<p style="text-decoration:line-through;"><?php echo "Price:"."$".$row2['regular_price']; ?></p>
					<br><a href="shop.php?catid=<?php echo $_GET['catid'];  ?>&cart=1&pid=<?php echo $row2['p_id']; ?>"><button  class="btn btn-default" style="">Add to Cart</button></a>
				</div>
				
			</div>
		
		
		<?php
	}
		?>
		</div>
	
	
<?php
	}
	}

?>
</div>





</div>

</div>






<!--Main Product area end-->






















<!--footer starts-->
<div class="footer row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8" style="padding-top:30px;">
		<div class="col-sm-6">
			<h4>ABOUT US</h4>
		    <p ><span class="glyphicon glyphicon-map-marker" style="color:#ffa500;"></span> 474 Ontario St Toronto, ON M4X 1M7 Canada</p>
		    <p><span class="glyphicon glyphicon-earphone" style="color:#ffa500;"></span> (+92)-3118673628</p>
		    <p><span class="glyphicon glyphicon-envelope" style="color:#ffa500;"></span> naveedullah.baber@gmail.com</p>
		    <ul class="social">
				<li><i class="fab fa-facebook-square"></i></li>
				<li><i class="fab fa-google-plus"></i></li>
				<li><i class="fab fa-instagram"></i></li>
				<li><i class="fab fa-linkedin"></i></li>
				<li><i class="fab fa-pinterest"></i></li>
			</ul>
		</div>
		<div class="col-sm-6">
			<h4 style="margin-left:60px;">INFORMATION</h4>
		    <ul class="info">
				<li>
					<ul>
					<li>About Us</li>
					<li>Contact Us</li>
					
					</ul>
				
				</li>
				<li>
				    <ul>
					<li>Privacy Policy</li>
					<li>Refund Policy</li>
					
					</ul>
				
				</li>
				<li>
					<ul>
					<li>Return Policy</li>
					<li>Top Brands</li>
					
					</ul>
				
				
				</li>
			</ul>
		
		
		</div>
	
	</div>
	
	<div class="col-sm-2"></div>



</div>
<!--footer ends-->
<!--footer bottom section start-->
<div class="row" style="min-height:89px; color:white; background-color:#2c2c2c; border-top:0.02px solid grey;">
	<div class="col-sm-2" >
	</div>
	<div class="col-sm-8" style="margin-top:20px;">
		<div class="col-sm-6">
		&copy 2018 All Right Reserved
		</div>
		<div class="col-sm-6">
			<ul class="payment">
				<li><i class="fab fa-cc-paypal"></i></li>
				<li><i class="fab fa-cc-mastercard"></i></li>
				<li><i class="fab fa-cc-jcb"></i></li>
				<li><i class="fab fa-cc-discover"></i></li>
				<li><i class="fab fa-cc-visa"></i></li>
				<li><i class="fab fa-cc-amazon-pay"></i></li>
				<li><i class="fab fa-cc-apple-pay"></i></li>
				<li><i class="fab fa-cc-stripe"></i></li>
				
		 
		 
			</ul>
		
		 
		</div>
	
	</div>
	<div class="col-sm-2"></div>
	
</div>
<!--footer bottom section end-->


</body>
</html>